package com.examplename.javamicroservicesorderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaMicroservicesOrderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaMicroservicesOrderServiceApplication.class, args);
	}

}
