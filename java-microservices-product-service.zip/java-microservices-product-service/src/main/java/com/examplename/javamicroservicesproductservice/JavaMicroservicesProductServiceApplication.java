package com.examplename.javamicroservicesproductservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaMicroservicesProductServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaMicroservicesProductServiceApplication.class, args);
	}

}
